/**
 * 校验 Agent - 一致性检查
 */
import { AIService } from '@/lib/ai/service'
import type { AIProvider } from '@/lib/ai/types'
import { buildValidatorPrompt as buildValidatorPromptV2, type ValidationReport as ValidationReportV2 } from '../prompts/chapter/validating-v2'
import type { CharacterProfile, PlotlineData } from '../engine/types'
import type { PopularFictionProfile } from '../engine/popular-fiction'

interface ValidatorInput {
  projectId: number
  chapterNo: number
  newChapterContent: string
  characterProfiles: CharacterProfile[]
  recentSummaries: { chapterNo: number; summary: string }[]
  memoryContext?: string
  worldSetting?: string | null
  openPlotlines: PlotlineData[]
  chapterTitle?: string
  chapterGoal?: string
  useEnhancedPrompt?: boolean
  provider?: AIProvider
  popularFictionProfile?: PopularFictionProfile | null
}

// 默认使用增强版校验
const buildValidatorPrompt = buildValidatorPromptV2
export type ValidatorValidationReport = ValidationReportV2

export async function validatorAgent(
  input: ValidatorInput
): Promise<ValidatorValidationReport> {
  const { projectId, chapterNo, newChapterContent, characterProfiles, recentSummaries, worldSetting, openPlotlines, chapterTitle, chapterGoal } = input

  // 获取可追踪的 AI Provider
  const provider = input.provider || await AIService.createProvider({
    projectId,
    usageType: 'VALIDATOR',
  })

  // 构建角色档案字符串
  const characterProfilesStr = characterProfiles
    .map(c => `【${c.name}】${c.role}: ${c.appearance || ''} ${c.personality || ''}`)
    .join('\n')

  // 构建伏笔追踪字符串
  const plotlinesStr = openPlotlines
    .map(p => `[伏笔#${p.id}] ${p.description} (埋于第${p.plantedAt}章, ${p.status})`)
    .join('\n')

  // 构建提示词
  const prompt = buildValidatorPrompt({
    chapterNo,
    newChapterContent,
    characterProfiles: characterProfilesStr,
    memoryContext: input.memoryContext,
    recentSummaries: recentSummaries.map(s => `第${s.chapterNo}章：${s.summary}`).join('\n'),
    worldSetting,
    openPlotlines: plotlinesStr,
    chapterTitle,
    chapterGoal,
    popularFictionProfile: input.popularFictionProfile,
  })

  // 执行校验
  const result = await provider.generate(prompt, {
    temperature: 0.3,
    maxTokens: 2500,
  })

  // 解析 JSON
  const jsonMatch = result.content.match(/\{[\s\S]*\}/)
  if (jsonMatch) {
    try {
      const report = JSON.parse(jsonMatch[0]) as ValidatorValidationReport
      return report
    } catch {
      return {
        result: 'retry',
        score: 40,
        issues: [{
          type: 'worldview',
          severity: 'major',
          description: '校验结果解析失败，需要重试',
          location: '全文',
          reference: '校验输出',
        }],
        characterUpdates: {},
        newPlotlines: [],
        resolvedPlotlines: [],
        qualityMetrics: {
          logicScore: 40,
          characterScore: 40,
          emotionScore: 40,
          styleScore: 40,
        },
      }
    }
  }

  // 无法解析时返回可疑报告，需要人工审核
  return {
    result: 'retry',
    score: 50,
    issues: [{
      type: 'worldview',
      severity: 'major',
      description: '无法解析校验结果，可能存在格式问题',
      location: '全文',
      reference: '校验输出',
    }],
    characterUpdates: {},
    newPlotlines: [],
    resolvedPlotlines: [],
    qualityMetrics: {
      logicScore: 50,
      characterScore: 50,
      emotionScore: 50,
      styleScore: 50,
    },
  }
}
