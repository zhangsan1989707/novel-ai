import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { z } from 'zod'
import { getAIProvider, buildPromptContext, buildNovelGenerationPrompt, createProviderFromDefaultConfig } from '@/lib/ai'
import { countChineseWords } from '@/lib/utils'
import { getMinimumChapterWordCount, isChapterWordCountSufficient } from '@/lib/ai/chapter-quality'
import { AIVendor } from '@/types'
import { logError } from '@/lib/logger'
import { toProjectDTO, toChapterDTO } from '@/types/dto'
import { recordAndApplyChapterCommit } from '@/lib/engine/chapter-commit'
import { buildChapterMemoryPack } from '@/lib/memory'

// ============================================
// Schema 验证
// ============================================

const generateSchema = z.object({
  chapterId: z.number().int().positive(),
  useContext: z.boolean().default(true),
  contextChapterCount: z.number().int().min(1).max(10).default(2),
  targetWordCount: z.number().int().positive().default(3000),
  temperature: z.number().min(0).max(2).default(0.7),
})

// ============================================
// API Handler
// ============================================

interface RouteParams {
  params: Promise<{ projectId: string }>
}

/**
 * POST /api/novel/projects/{projectId}/generate
 * 非流式生成章节内容
 */
export async function POST(request: NextRequest, { params }: RouteParams) {
  let projectIdNum: number | null = null
  let chapterId: number | undefined
  try {
    const { projectId } = await params
    projectIdNum = parseInt(projectId)

    if (isNaN(projectIdNum)) {
      return NextResponse.json(
        { success: false, error: { code: 'INVALID_ID', message: '无效的项目ID' } },
        { status: 400 }
      )
    }

    const body = await request.json()
    const parsedData = generateSchema.parse(body)
    chapterId = parsedData.chapterId
    const {
      useContext,
      contextChapterCount,
      targetWordCount,
      temperature,
    } = parsedData

    // 获取项目信息
    const rawProject = await prisma.novelProject.findUnique({
      where: { id: projectIdNum },
      include: {
        aiModelConfig: true,
      },
    })

    if (!rawProject) {
      return NextResponse.json(
        { success: false, error: { code: 'NOT_FOUND', message: '项目不存在' } },
        { status: 404 }
      )
    }

    // 类型转换
    const project = toProjectDTO(rawProject)

    // 获取章节信息
    const rawChapter = await prisma.novelChapter.findUnique({
      where: { id: chapterId },
    })

    if (!rawChapter || rawChapter.projectId !== projectIdNum) {
      return NextResponse.json(
        { success: false, error: { code: 'NOT_FOUND', message: '章节不存在' } },
        { status: 404 }
      )
    }

    const chapter = toChapterDTO(rawChapter)

    // 获取前文章节
    const previousChapters = await prisma.novelChapter.findMany({
      where: {
        projectId: projectIdNum,
        id: { not: chapterId },
        status: { in: ['COMPLETED', 'REVIEWING'] },
        content: { not: null },
      },
      orderBy: { chapterNumber: 'asc' },
    })

    // 构建提示词上下文
    const memoryPack = await buildChapterMemoryPack(projectIdNum, chapter.chapterNumber, {
      recentChapterCount: contextChapterCount,
      recentVolumeCount: 2,
      characterLimit: 10,
      plotlineLimit: 10,
      researchLimit: 3,
    })
    const context = await buildPromptContext(
      project,
      chapter,
      previousChapters.map(toChapterDTO),
      {
        useContext,
        contextChapterCount,
        includeStageOutline: true,
        memoryContext: memoryPack.writerContext,
      }
    )

    // 构建完整提示词
    const prompt = buildNovelGenerationPrompt(context, {
      useContext,
      contextChapterCount,
      targetWordCount,
      includeStageOutline: true,
    })

    // 更新章节状态
    await prisma.novelChapter.update({
      where: { id: chapterId },
      data: {
        status: 'GENERATING',
        generationPrompt: prompt,
        generationCount: { increment: 1 },
        lastGeneratedTime: new Date(),
      },
    })

    // 获取 AI Provider
    let provider
    if (project.aiModelConfig) {
      provider = getAIProvider(project.aiModelConfig.vendor as AIVendor, {
        vendor: project.aiModelConfig.vendor as AIVendor,
        modelId: project.aiModelConfig.modelId,
        apiKey: project.aiModelConfig.apiKey || '',
        apiEndpoint: project.aiModelConfig.apiEndpoint || undefined,
      })
    } else {
      // 使用默认配置（从数据库）
      provider = await createProviderFromDefaultConfig()
    }

    // 非流式生成
    const result = await provider.generate(prompt, { temperature })

    // 解析标题和内容
    let extractedTitle: string | undefined
    let extractedContent = result.content
    
    const titleMatch = result.content.match(/^标题：(.+)$/m)
    const contentMatch = result.content.match(/^内容：$\s*([\s\S]*)$/m)
    
    if (titleMatch && contentMatch) {
      let aiTitle = titleMatch[1].trim()
      aiTitle = aiTitle.replace(/^第\d+章\s*/, '')
      extractedTitle = aiTitle
      extractedContent = contentMatch[1].trim()
    }

    const wordCount = countChineseWords(extractedContent)

    // 保存生成内容
    const chapterReady = isChapterWordCountSufficient(wordCount, targetWordCount, chapter.chapterNumber)

    await recordAndApplyChapterCommit(projectIdNum, chapterId, {
      chapterNo: chapter.chapterNumber,
      chapterTitle: extractedTitle || chapter.title,
      content: extractedContent,
      qualityStatus: chapterReady ? 'completed' : 'reviewing',
      targetWordCount,
      currentWordCount: wordCount,
      agentType: 'WRITER',
      emittedAt: new Date().toISOString(),
    }, 'generate')

    return NextResponse.json({
      success: true,
      data: {
        chapterId,
        content: extractedContent,
        title: extractedTitle,
        wordCount,
        minimumWordCount: getMinimumChapterWordCount(targetWordCount, chapter.chapterNumber),
        qualityStatus: chapterReady ? 'completed' : 'reviewing',
        usage: result.usage,
      },
    })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { success: false, error: { code: 'VALIDATION_ERROR', message: error.issues[0]?.message || '验证失败' } },
        { status: 400 }
      )
    }
    logError(error instanceof Error ? error : new Error(String(error)), { type: 'generate', chapterId })
    return NextResponse.json(
      { success: false, error: { code: 'GENERATE_ERROR', message: '生成失败' } },
      { status: 500 }
    )
  }
}
